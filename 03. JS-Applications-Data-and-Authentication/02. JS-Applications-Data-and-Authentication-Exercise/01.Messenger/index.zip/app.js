async function attachEvents() {
  let authorName = document.querySelector(`input[name="author"]`);
  let msgText = document.querySelector(`input[name="content"]`);
  let messages = document.getElementById("messages");
  let submit = document.getElementById("submit");
  let refresh = document.getElementById("refresh");

  submit.addEventListener("click", sendMsg);
  refresh.addEventListener("click", showAllMsg);

  async function sendMsg() {
    if (authorName.value == "" || msgText.value == "") {
      return;
    }
    let msg = {
      author: authorName.value,
      content: msgText.value,
    };
    fetch("http://localhost:3030/jsonstore/messenger", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(msg),
    });
    authorName.value = "";
    msgText.value = "";
  }
  async function showAllMsg() {
    let respond = await fetch("http://localhost:3030/jsonstore/messenger");
    let data = await respond.json();
    messages.textContent = "";
    let allMsg = [];
    Object.values(data).forEach((messageObj) => {
      allMsg.push(`${messageObj.author}: ${messageObj.content}`);
    });
    messages.textContent = allMsg.join(`\n`);
  }
}

attachEvents();
